Welcome to Minecraft Sparta Military Technologies mod pack.
All configs are included. Should be no conflicts. Create seperate game directory to use MCSMT and MCS simulateously.

Inlcuded mods:
	ICBM
	Mekanism
	Flan's Mods
		WWII pack
		Parts Pack
		Titan Pack
		Weapons Pack
		Modern Weapons Pack
	IC2
		Gravitation Suite
		Nuclear Control
	Tinker's Construct
	Natura
	Open Blocks
	Extra Utilities
	Portal Gun
	Gravity Gun
	NEI
	Bibliocraft
	Project: RED
	Thermal Expansion
	Redsone Arsenal (OMNIWRENCH!!!)
	Ender Storage
	Applied Energistics
	Switches
	OptiFine
	WR-CBE (Wireless Redstone-Chicken_Bones Edition)
	